import onnx
from onnx.helper import make_model, ModelProto

from quantizer.interfaces.transformer import Transformer
from quantizer.frontend.onnx.transformer import utils
from quantizer.frontend.onnx.utils.check_model import check_model

from onnxruntime_tools.transformers.onnx_model import OnnxModel
from onnxruntime_tools.transformers.fusion_layernorm import FusionLayerNormalization


class BertOnnxModel(OnnxModel):
    def __init__(self, model):
        super().__init__(model)

    def fuse_layer_normalization(self):
        fusion = FusionLayerNormalization(self)
        fusion.apply()


class FuseLayerNormalization(Transformer):
    """
    from:
        Input --> ReduceMean --> S --> Pow --> ReduceMean --> Add --> Sqrt --> D
              -----------------> ub -----------------------------------------> iv --> Mul --> Add Output
    to:
        LayerNormalization
    """

    def transform(self, model: onnx.ModelProto) -> onnx.ModelProto:
        orig_model = ModelProto()
        orig_model.CopyFrom(model)

        optimizer = BertOnnxModel(model)
        optimizer.fuse_layer_normalization()

        model = optimizer.model
        layer_norm_by_input_name = {node.input[0]: node for node in model.graph.node
                                    if node.op_type == 'LayerNormalization'}

        # nodes are not topologically sorted as a result of onnxruntime_tools optimization
        sorted_nodes = []
        visited = 0
        for node in orig_model.graph.node:
            if node in model.graph.node:
                sorted_nodes.append(node)
                if node.output[0] in layer_norm_by_input_name.keys():
                    sorted_nodes.append(layer_norm_by_input_name[node.output[0]])
                visited += 1

        if not visited:
            sorted_nodes = model.graph.node

        model = utils.rebuild_model(model, sorted_nodes)
        check_model(model)

        return model
